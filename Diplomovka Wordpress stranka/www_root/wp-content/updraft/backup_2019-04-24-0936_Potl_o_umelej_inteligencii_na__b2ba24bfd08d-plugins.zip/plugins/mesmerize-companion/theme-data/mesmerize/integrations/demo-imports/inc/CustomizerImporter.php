<?php


namespace ExtendThemes\DemoImportIntegration;


use OCDI\CustomizerOption;
use OCDI\Helpers;
use OCDI\OneClickDemoImport;

class CustomizerImporter
{
    
    public static function import($customizer_import_file_path)
    {
        $ocdi          = OneClickDemoImport::get_instance();
        $log_file_path = $ocdi->get_log_file_path();
        
        // Try to import the customizer settings.
        $results = self::import_customizer_options($customizer_import_file_path);
        
        // Check for errors, else write the results to the log file.
        if (is_wp_error($results)) {
            $error_message = $results->get_error_message();
            
            // Add any error messages to the frontend_error_messages variable in OCDI main class.
            $ocdi->append_to_frontend_error_messages($error_message);
            
            // Write error to log file.
            Helpers::append_to_file(
                $error_message,
                $log_file_path,
                esc_html__('Importing customizer settings', 'pt-ocdi')
            );
        } else {
            // Add this message to log file.
            $log_added = Helpers::append_to_file(
                esc_html__('Customizer settings import finished!', 'pt-ocdi'),
                $log_file_path,
                esc_html__('Importing customizer settings', 'pt-ocdi')
            );
        }
    }
    
    public static function import_customizer_options($import_file_path)
    {
        // Setup global vars.
        global $wp_customize;
        
        // Setup internal vars.
        $templates = apply_filters("extendthemes_ocdi_customizer_templates", array(get_template()));
        
        // Make sure we have an import file.
        if ( ! file_exists($import_file_path)) {
            return new \WP_Error(
                'missing_cutomizer_import_file',
                sprintf(
                    esc_html__('Error: The customizer import file is missing! File path: %s', 'pt-ocdi'),
                    $import_file_path
                )
            );
        }
        
        // Get the upload data.
        $raw = Helpers::data_from_file($import_file_path);
        
        // Make sure we got the data.
        if (is_wp_error($raw)) {
            return $raw;
        }
        
        $data = unserialize($raw);
        // Data checks.
        if ( ! is_array($data) && ( ! isset($data['template']) || ! isset($data['mods']))) {
            return new \WP_Error(
                'customizer_import_data_error',
                esc_html__('Error: The customizer import file is not in a correct format. Please make sure to use the correct customizer import file.', 'pt-ocdi')
            );
        }
        if ( ! in_array($data['template'], $templates)) {
            return new \WP_Error(
                'customizer_import_wrong_theme',
                esc_html__('Error: The customizer import file is not suitable for current theme. You can only import customizer settings for the same theme or a child theme.', 'pt-ocdi')
            );
        }
        
        $data = apply_filters('extendthemes_ocdi_customizer_data', $data);
        
        // Import images.
        if (apply_filters('pt-ocdi/customizer_import_images', true)) {
            $data['mods'] = self::import_customizer_images($data['mods']);
        }
        
        // Import custom options.
        if (isset($data['options'])) {
            // Require modified customizer options class.
            if ( ! class_exists('\WP_Customize_Setting')) {
                require_once ABSPATH . 'wp-includes/class-wp-customize-setting.php';
            }
            
            foreach ($data['options'] as $option_key => $option_value) {
                $option = new CustomizerOption($wp_customize, $option_key, array(
                    'default'    => '',
                    'type'       => 'option',
                    'capability' => 'edit_theme_options',
                ));
                
                $option->import($option_value);
            }
        }
        
        // Should the customizer import use the WP customize_save* hooks?
        $use_wp_customize_save_hooks = apply_filters('pt-ocdi/enable_wp_customize_save_hooks', false);
        
        if ($use_wp_customize_save_hooks) {
            do_action('customize_save', $wp_customize);
        }
        
        $theme = get_option('stylesheet');
        update_option("theme_mods_$theme", $data['mods']);
        
        if ($use_wp_customize_save_hooks) {
            do_action('customize_save_after', $wp_customize);
        }
    }
    
    
    private static function import_customizer_images($mods)
    {
        foreach ($mods as $key => $val) {
            if (self::customizer_is_image_url($val)) {
                $data = self::customizer_sideload_image($val);
                if ( ! is_wp_error($data)) {
                    $mods[$key] = $data->url;
                    
                    // Handle header image controls.
                    if (isset($mods[$key . '_data'])) {
                        $mods[$key . '_data'] = $data;
                        update_post_meta($data->attachment_id, '_wp_attachment_is_custom_header', get_stylesheet());
                    }
                }
            }
        }
        
        return $mods;
    }
    
    
    private static function customizer_sideload_image($file)
    {
        $data = new \stdClass();
        
        if ( ! function_exists('media_handle_sideload')) {
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
        }
        if ( ! empty($file)) {
            // Set variables for storage, fix file filename for query strings.
            preg_match('/[^\?]+\.(jpe?g|jpe|gif|png)\b/i', $file, $matches);
            $file_array         = array();
            $file_array['name'] = basename($matches[0]);
            
            // Download file to temp location.
            $file_array['tmp_name'] = download_url($file);
            
            // If error storing temporarily, return the error.
            if (is_wp_error($file_array['tmp_name'])) {
                return $file_array['tmp_name'];
            }
            
            // Do the validation and storage stuff.
            $id = media_handle_sideload($file_array, 0);
            
            // If error storing permanently, unlink.
            if (is_wp_error($id)) {
                unlink($file_array['tmp_name']);
                
                return $id;
            }
            
            // Build the object to return.
            $meta                = wp_get_attachment_metadata($id);
            $data->attachment_id = $id;
            $data->url           = wp_get_attachment_url($id);
            $data->thumbnail_url = wp_get_attachment_thumb_url($id);
            $data->height        = $meta['height'];
            $data->width         = $meta['width'];
        }
        
        return $data;
    }
    
    private static function customizer_is_image_url($string = '')
    {
        if (is_string($string)) {
            if (preg_match('/\.(jpg|jpeg|png|gif)/i', $string)) {
                return true;
            }
        }
        
        return false;
    }
}
