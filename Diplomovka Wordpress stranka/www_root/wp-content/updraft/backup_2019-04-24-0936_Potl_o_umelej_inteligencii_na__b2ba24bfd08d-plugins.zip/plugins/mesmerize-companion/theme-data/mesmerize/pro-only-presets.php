<?php

return array (
  'pro_pro-header-0' => 
  array (
    'index' => 5,
    'id' => 'pro_pro-header-0_5',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-0.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-0.jpg',
    'description' => 'header preset 6',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-1' => 
  array (
    'index' => 6,
    'id' => 'pro_pro-header-1_6',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-1.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-1.jpg',
    'description' => 'header preset 7',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-10' => 
  array (
    'index' => 7,
    'id' => 'pro_pro-header-10_7',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-10.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-10.jpg',
    'description' => 'header preset 8',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-11' => 
  array (
    'index' => 8,
    'id' => 'pro_pro-header-11_8',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-11.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-11.jpg',
    'description' => 'header preset 9',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-12' => 
  array (
    'index' => 9,
    'id' => 'pro_pro-header-12_9',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-12.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-12.jpg',
    'description' => 'header preset 10',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-13' => 
  array (
    'index' => 10,
    'id' => 'pro_pro-header-13_10',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-13.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-13.jpg',
    'description' => 'header preset 11',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-14' => 
  array (
    'index' => 11,
    'id' => 'pro_pro-header-14_11',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-14.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-14.jpg',
    'description' => 'header preset 12',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-16' => 
  array (
    'index' => 12,
    'id' => 'pro_pro-header-16_12',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-16.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-16.jpg',
    'description' => 'header preset 13',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-17' => 
  array (
    'index' => 13,
    'id' => 'pro_pro-header-17_13',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-17.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-17.jpg',
    'description' => 'header preset 14',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-18' => 
  array (
    'index' => 14,
    'id' => 'pro_pro-header-18_14',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-18.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-18.jpg',
    'description' => 'header preset 15',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-2' => 
  array (
    'index' => 15,
    'id' => 'pro_pro-header-2_15',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-2.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-2.jpg',
    'description' => 'header preset 16',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-3' => 
  array (
    'index' => 16,
    'id' => 'pro_pro-header-3_16',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-3.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-3.jpg',
    'description' => 'header preset 17',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-4' => 
  array (
    'index' => 17,
    'id' => 'pro_pro-header-4_17',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-4.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-4.jpg',
    'description' => 'header preset 18',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-5' => 
  array (
    'index' => 18,
    'id' => 'pro_pro-header-5_18',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-5.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-5.jpg',
    'description' => 'header preset 19',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-6' => 
  array (
    'index' => 19,
    'id' => 'pro_pro-header-6_19',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-6.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-6.jpg',
    'description' => 'header preset 20',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-7' => 
  array (
    'index' => 20,
    'id' => 'pro_pro-header-7_20',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-7.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-7.jpg',
    'description' => 'header preset 21',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-8' => 
  array (
    'index' => 21,
    'id' => 'pro_pro-header-8_21',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-8.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-8.jpg',
    'description' => 'header preset 22',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
  'pro_pro-header-9' => 
  array (
    'index' => 22,
    'id' => 'pro_pro-header-9_22',
    'thumb' => '//extendthemes.com/assets/mesmerize/previews/headers/thumb-pro-header-9.jpg',
    'preview' => '//extendthemes.com/assets/mesmerize/previews/headers/pro-header-9.jpg',
    'description' => 'header preset 23',
    'settings' => 
    array (
    ),
    'pro-only' => true,
  ),
);
