<div class="three-col">
	<div class="col">
		<h4><?php esc_html_e( 'ONE TIME PAYMENT', 'vmagazine-news' ); ?></h4>
		<p><?php esc_html_e( 'No renewal needed', 'vmagazine-news' ); ?></p>
	</div>

	<div class="col">
		<h4><?php esc_html_e( 'UNLIMITED DOMAIN LICENCE', 'vmagazine-news' ); ?></h4>
		<p><?php esc_html_e( 'Use in as many website as you need', 'vmagazine-news' ); ?></p>
	</div>

	<div class="col">
		<h4><?php esc_html_e( 'FREE UPDATES FOR LIFE TIME', 'vmagazine-news' ); ?></h4>
		<p><?php esc_html_e( 'Keep upto date', 'vmagazine-news' ); ?></p>
	</div>
</div>

<table class="comparison-table">
	<tr>
		<td>
			<span><?php esc_html_e('Upgrade to Pro', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Upgrade to pro version for additional features and better supports.', 'vmagazine-news'); ?></p>
		</td>
		<td colspan="2">
			<a target="__blank" class="buy-pro-btn" href="https://themeforest.net/item/vmagazine-blog-and-magazine-wordpress-themes/21950900"><?php esc_html_e( 'Buy Now ($44 only)', 'vmagazine-news' ); ?></a>
		</td>
	</tr>
	<tr>
		<th><?php esc_html_e('Features', 'vmagazine-news'); ?></th>
		<th><?php esc_html_e('Free', 'vmagazine-news'); ?></th>
		<th><?php esc_html_e('Pro', 'vmagazine-news'); ?></th>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('One Click Demo Import.', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Tired of configuring site from scratch. Installation of demo is just one click away.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/no.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Live Ajax Search', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Find your considered article fast and easy.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Header Layout', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Configure your website with any header layouts according to your need
', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<?php echo esc_html__('1', 'vmagazine-news'); ?>
		</td>
		<td>
			<?php echo esc_html__('4', 'vmagazine-news'); ?>
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Build in Mega Menu', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Configure your mega menu without any hassles, with easy configuration options.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/no.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Inbuilt Widgets', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Choose any one header layout from the available 2 Layouts.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<?php echo esc_html__('8', 'vmagazine-news'); ?>
		</td>
		<td>
			<?php echo esc_html__('22', 'vmagazine-news'); ?>
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Ads Placements', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Place your ads anywhere you prefer using page builder', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Preloader Option', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Display preloader before the site content loads fully in your website.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/no.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Typography Option', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Change the fonts settings for the entire site.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/no.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Responsive Design', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Displays fine in device with screen sizes.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Unlimited theme colors', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Offers unlimited theme colors choose any of your choice and create a delightful site.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('WPML  Compatible', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('The theme is fully compatible with WordPress Multilingual plugin WMPL and Polylang.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Woocommerce Compatible', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Supports the Woocommerce plugin to build a ecommerce based website.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('SEO Optimized', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Google will love it.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('RTL Support', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('The theme is compatible with all RTL (Right to Left) languages like Arabic, Persian and Hebrew.', 'vmagazine-news'); ?></p>
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/no.png'); ?>">
		</td>
		<td>
			<img src="<?php echo esc_url(get_template_directory_uri().'/inc/welcome/css/yes.png'); ?>">
		</td>
	</tr>
	<tr>
		<td>
			<span><?php esc_html_e('Upgrade to Pro', 'vmagazine-news'); ?></span>
			<p><?php esc_html_e('Upgrade to pro version for additional features and better supports.', 'vmagazine-news'); ?></p>
		</td>
		<td colspan="2">
			<a target="__blank" class="buy-pro-btn" href="https://themeforest.net/item/vmagazine-blog-and-magazine-wordpress-themes/21950900"><?php esc_html_e( 'Buy Now ($44 only)', 'vmagazine-news' ); ?></a>
		</td>
	</tr>
</table>