/* This is just dummy file for code inspection to calm down about ApolloParams object. This file is not attached in site in any way! */

ApolloParams = {
	'ajaxurl'                   : '',
	'site_url'                  : '',
	'defimgurl'                 : '',
	'msg_cookie_string'         : '',
	'hide_content_under_header' : '',
	'writing_effect_mobile'     : '',
	'writing_effect_speed'      : '',
	'default_header_variant'    : '',
	'header_color_variants'     : '',
	'show_header_at'            : '',
	'load_more'                 : '',
	'loading_items'             : '',
	'anchors_in_bar'            : '',
	'scroll_to_anchor'          : '',
	'close_mobile_menu_on_click': '',
	'menu_overlay_on_click'     : '',
	'allow_mobile_menu'         : '',
	'submenu_opener'            : '',
	'submenu_closer'            : '',
	'submenu_third_lvl_opener'  : '',
	'submenu_third_lvl_closer'  : '',
	'posts_brick_margin'        : '',
	'posts_layout_mode'         : '',
	'products_brick_margin'     : '',
	'products_layout_mode'      : '',
	'albums_list_brick_margin'  : '',
	'albums_list_layout_mode'   : '',
	'album_bricks_thumb_video'  : '',
	'works_list_brick_margin'   : '',
	'works_list_layout_mode'    : '',
	'work_bricks_thumb_video'   : '',
	'people_list_brick_margin'  : '',
	'people_list_layout_mode'   : '',

	'header_sticky_top_bar'       : '',
	'header_normal_social_colors' : '',
	'header_light_social_colors'  : '',
	'header_dark_social_colors'   : '',
	'header_sticky_social_colors' : '',
	'lg_lightbox_share'           : '',
	'lg_lightbox_controls'        : '',
	'lg_lightbox_download'        : '',
	'lg_lightbox_counter'         : '',
	'lg_lightbox_thumbnail'       : '',
	'lg_lightbox_show_thumbs'     : '',
	'lg_lightbox_autoplay_open'   : '',
	'lg_lightbox_autoplay'        : '',
	'lg_lightbox_autoplay_pause'  : '',
	'lg_lightbox_progressbar'     : '',
	'lg_lightbox_full_screen'     : '',
	'lg_lightbox_zoom'            : '',
	'lg_lightbox_mode'            : '',
	'lg_lightbox_speed'           : '',
	'lg_lightbox_preload'         : '',
	'lg_lightbox_hide_delay'      : '',
	'lightbox_single_post'        : '',
	'proofing_add_comment'        : '',
	'proofing_comment_placeholder': '',
	'proofing_mark_item'          : '',
	'proofing_uncheck_item'       : '',
	'album_id'                    : '',
	'proofing_nonce'              : '',
	'proofing_manual_ids'         : ''
};


A13Scroller = {
	'a13CellWidth'      : '',
	'a13CellWidthMobile': '',
	'a13Effect'         : '',
	'a13MainSlider'     : '',
	'a13Parallax'       : '',
	'a13Ratio'          : '',
	'a13ShowDesc'       : '',
	'a13Socials'        : '',
	'a13WindowHigh'     : '',
	'wrapAround'        : ''
};

A13FECustomizerControls = {
	'ajaxurl'            : '',
	'options_name'       : '',
	'google_fonts'       : '',
	'human_font_variants': '',
	'notices'            : ''
};
A13FECustomizerControls = {
	'options_name': '',
	'cursors'     : ''
};