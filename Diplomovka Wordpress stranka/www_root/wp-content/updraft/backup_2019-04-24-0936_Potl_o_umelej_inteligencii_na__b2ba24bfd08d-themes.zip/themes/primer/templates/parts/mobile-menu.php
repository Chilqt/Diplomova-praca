<?php
/**
 * Display the mobile menu
 *
 * @package Primer
 * @since   1.0.0
 */

?>

<div class="menu-toggle" id="menu-toggle">
	<div></div>
	<div></div>
	<div></div>
</div><!-- #menu-toggle -->
